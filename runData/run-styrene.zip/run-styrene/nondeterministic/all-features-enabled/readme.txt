TODO : investigate why "with memory exponential" is not running to the end and displays "processus arreté" 
