all-features-enabled :
	LH_SEARCH n+1 points at each iteration
	SPECULATIVE_SEARCH with default parameters
	ANISOTROPIC_MESH with default parameters
	FRAME_CENTER_USE_CACHE
	OPPORTUNISTIC_EVAL true

searches-opportunism :
        LH_SEARCH n+1 points at each iteration
        SPECULATIVE_SEARCH with default parameters
	OPPORTUNIStIC_EVAL true 

wo-opportunism :
        LH_SEARCH n+1 points at each iteration
        SPECULATIVE_SEARCH with default parameters
        OPPORTUNIStIC_EVAL false 

