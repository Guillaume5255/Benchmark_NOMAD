geometryInfluence : profiles de comparaison entre classique (2n points), Multi( (2n+1)*2n points), Oignon( (2n+1)*2n points), Enrichie( (2n+1)*2n points) pour voir si la manière de générer les points change quelquechose.

IntensificationInfluence : coparaison pour Oignon et Enrichie sur la manière dont la gestion dynamique du nombre de points influe sur la résolution des problèmes.

InsideFrameInfluence : comparaison Pour Enrichie quand les points de sonde sont générés uniquement sur le cadre ou également à l'intérieur du cadre.
