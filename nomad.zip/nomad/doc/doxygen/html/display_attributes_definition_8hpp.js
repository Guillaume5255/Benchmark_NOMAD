var display_attributes_definition_8hpp =
[
    [ "__NOMAD400_DISPLAYATTRIBUTESDEFINITION__", "display_attributes_definition_8hpp.html#a3e289269583f8e4e09dd798752d3d32c", null ],
    [ "_definition", "display_attributes_definition_8hpp.html#a68ca731e70b4c5ef6ca341d4fa668775", null ]
];