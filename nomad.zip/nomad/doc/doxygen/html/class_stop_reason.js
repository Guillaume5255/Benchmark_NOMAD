var class_stop_reason =
[
    [ "StopReason", "class_stop_reason.html#a9a4f4b6f2a5cb9c6a152ecf7f5c17841", null ],
    [ "~StopReason", "class_stop_reason.html#a4c6731c16519e3bb62ef82cdc5bdee15", null ],
    [ "checkTerminate", "class_stop_reason.html#a5c2e6b525c1bc8e105fdbe8e9bbf6f89", null ],
    [ "dict", "class_stop_reason.html#a698a837f9fd6f55772f42dacfd75fe64", null ],
    [ "get", "class_stop_reason.html#ac9300e7d058a58778e0f2b8f0a1628f7", null ],
    [ "getStopReasonAsString", "class_stop_reason.html#acc6e09be3d7a96108db3765419c65a43", null ],
    [ "isStarted", "class_stop_reason.html#aa1923df3eb9e569e7168fe6de3bafb42", null ],
    [ "set", "class_stop_reason.html#a1fa8b2b0f1429152c2c3a5ff19f299c4", null ],
    [ "setStarted", "class_stop_reason.html#a33f419dd75714f318b8758dea785ef64", null ],
    [ "testValidity", "class_stop_reason.html#abb1698f6053f29524b2582c1386378ab", null ],
    [ "_stopReason", "class_stop_reason.html#a694b20d1e207cd5c7502a6065108d399", null ]
];