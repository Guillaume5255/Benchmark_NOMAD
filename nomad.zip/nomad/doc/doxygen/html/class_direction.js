var class_direction =
[
    [ "Direction", "class_direction.html#a152558386a6d194efa9c1f51b72e5fb1", null ],
    [ "Direction", "class_direction.html#a33689e71f4e7936d49620f9d478a24c5", null ],
    [ "Direction", "class_direction.html#a2a17c6ee34045ef136bcfc99e8154810", null ],
    [ "~Direction", "class_direction.html#a9dc10040126d32d44f5e683ec940e3cd", null ],
    [ "cos", "class_direction.html#a436b875118bdd81d60dd127eda9d983b", null ],
    [ "dotProduct", "class_direction.html#ad1900c54d59bf67127f1d86286ac4c1d", null ],
    [ "infiniteNorm", "class_direction.html#a94204de7841cb290c6a8a9699d21126c", null ],
    [ "norm", "class_direction.html#a4b8c88b694542c36fcf9f3bad2b54ac8", null ],
    [ "operator=", "class_direction.html#a2ba52cb434dfee1c7e121658135cb011", null ],
    [ "squaredNorm", "class_direction.html#a3b67fb894cf4641d71901134b0ae30b5", null ]
];