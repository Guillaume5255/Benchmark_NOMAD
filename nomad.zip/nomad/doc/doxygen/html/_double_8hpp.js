var _double_8hpp =
[
    [ "Double", "class_double.html", "class_double" ],
    [ "NotDefined", "class_double_1_1_not_defined.html", "class_double_1_1_not_defined" ],
    [ "InvalidValue", "class_double_1_1_invalid_value.html", "class_double_1_1_invalid_value" ],
    [ "max", "_double_8hpp.html#a3eac18b72d527f2322ed5ae2bb78424c", null ],
    [ "min", "_double_8hpp.html#a25a47906077a54b7bd3666fa9e13790c", null ],
    [ "operator!=", "_double_8hpp.html#aab2413d08b2fcb35259686c565cb3059", null ],
    [ "operator*", "_double_8hpp.html#a617bcc1e0fc5850541ad18d92a35b845", null ],
    [ "operator+", "_double_8hpp.html#a4dcb048d6dc2b357e64b01800f2a3fda", null ],
    [ "operator-", "_double_8hpp.html#aa590724094eb797ecb3ee5af02f690aa", null ],
    [ "operator-", "_double_8hpp.html#a1eca576b6125d27b6aea1f8490954340", null ],
    [ "operator/", "_double_8hpp.html#ad2b57d963fd05b5cabf7112f4da82c00", null ],
    [ "operator<", "_double_8hpp.html#ab9b4effd842f9b6a2bef9d73bbd79b08", null ],
    [ "operator<=", "_double_8hpp.html#a812a4a08846008fdc3c7bf8a2106bea7", null ],
    [ "operator==", "_double_8hpp.html#acfe8bd4e655834b0fd24d1861d0841c6", null ],
    [ "operator>", "_double_8hpp.html#a6c745b2717df12a613470a681e673c0f", null ],
    [ "operator>=", "_double_8hpp.html#a729932942749136fa5e72ed56abcd24c", null ],
    [ "operator>>", "_double_8hpp.html#ab376828444a3c9525eb3da1c8a8e18a1", null ]
];