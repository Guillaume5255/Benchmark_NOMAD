var class_termination =
[
    [ "Termination", "class_termination.html#a1c48ab60a87b8154036ef166f6422111", null ],
    [ "~Termination", "class_termination.html#a0c97f2471b9d8a99a79c2cf93542140b", null ],
    [ "end", "class_termination.html#aeb625a2457092c3454d6b0ca94b6ef29", null ],
    [ "init", "class_termination.html#a08a252e2fcb154883d55cd92a1b81310", null ],
    [ "run", "class_termination.html#ab7dce22377d28ba6ccd86212aa432cc2", null ],
    [ "start", "class_termination.html#ae70f0023e36c3db964f7bdcad6802eb5", null ],
    [ "terminate", "class_termination.html#a748fce06edfb7a80c1482486c5b40b78", null ]
];