var _mega_iteration_8hpp =
[
    [ "MegaIteration", "class_mega_iteration.html", "class_mega_iteration" ],
    [ "operator<<", "_mega_iteration_8hpp.html#ae491ae1d7b91e4cb947269c70875f2c5", null ],
    [ "operator>>", "_mega_iteration_8hpp.html#a413dff6285e34567894becb6eb8bd969", null ]
];