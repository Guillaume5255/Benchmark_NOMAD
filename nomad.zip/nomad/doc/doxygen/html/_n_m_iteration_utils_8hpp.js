var _n_m_iteration_utils_8hpp =
[
    [ "NMIterationUtils", "class_n_m_iteration_utils.html", "class_n_m_iteration_utils" ],
    [ "NMStepType", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9", [
      [ "UNSET", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9a666a87025ab0d8965e221050c8948001", null ],
      [ "INITIAL", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9a91d26e4b2b105c74655093c9becd30b7", null ],
      [ "REFLECT", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9ae4f6a05f82ed398f984f4bc1a55838df", null ],
      [ "EXPAND", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9a8f9d21d221f9e47228ff3747ee2992d7", null ],
      [ "OUTSIDE_CONTRACTION", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9ab73f6c9692e4818626294aec2365ad1f", null ],
      [ "INSIDE_CONTRACTION", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9a28a89a5cc3e34f2d11da278f33c86a51", null ],
      [ "SHRINK", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9a7505f647dc2c54b8fb665d1a7c34c5aa", null ],
      [ "INSERT_IN_Y", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9a496e98bd3960c856f033af83f544aa06", null ],
      [ "CONTINUE", "_n_m_iteration_utils_8hpp.html#ac17a781823c601ed759a139868d8a6c9a2f453cfe638e57e27bb0c9512436111e", null ]
    ] ]
];