var class_double_1_1_invalid_value =
[
    [ "InvalidValue", "class_double_1_1_invalid_value.html#aeae89b939cccb0e1c07da7153f437448", null ]
];