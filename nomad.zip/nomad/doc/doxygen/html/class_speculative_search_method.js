var class_speculative_search_method =
[
    [ "SpeculativeSearchMethod", "class_speculative_search_method.html#a26b84599b9615fc45e1626a363e2954c", null ],
    [ "generateTrialPoints", "class_speculative_search_method.html#acce372c118128de41e494312de190cbe", null ],
    [ "init", "class_speculative_search_method.html#a9c56982f2b545690de87c6c56e4b5937", null ]
];