/*---------------------------------------------------------------------------------*/
/*  NOMAD - Nonlinear Optimization by Mesh Adaptive Direct Search -                */
/*                                                                                 */
/*  NOMAD - Version 4.0.0 has been created by                                      */
/*                 Viviane Rochon Montplaisir  - Polytechnique Montreal            */
/*                 Christophe Tribes           - Polytechnique Montreal            */
/*                                                                                 */
/*  The copyright of NOMAD - version 4.0.0 is owned by                             */
/*                 Sebastien Le Digabel        - Polytechnique Montreal            */
/*                 Viviane Rochon Montplaisir  - Polytechnique Montreal            */
/*                 Christophe Tribes           - Polytechnique Montreal            */
/*                                                                                 */
/*  NOMAD v4 has been funded by Rio Tinto, Hydro-Québec, NSERC (Natural Science    */
/*  and Engineering Research Council of Canada), INOVEE (Innovation en Energie     */
/*  Electrique and IVADO (The Institute for Data Valorization)                     */
/*                                                                                 */
/*  NOMAD v3 was created and developed by Charles Audet, Sebastien Le Digabel,     */
/*  Christophe Tribes and Viviane Rochon Montplaisir and was funded by AFOSR       */
/*  and Exxon Mobil.                                                               */
/*                                                                                 */
/*  NOMAD v1 and v2 were created and developed by Mark Abramson, Charles Audet,    */
/*  Gilles Couture, and John E. Dennis Jr., and were funded by AFOSR and           */
/*  Exxon Mobil.                                                                   */
/*                                                                                 */
/*  Contact information:                                                           */
/*    Polytechnique Montreal - GERAD                                               */
/*    C.P. 6079, Succ. Centre-ville, Montreal (Quebec) H3C 3A7 Canada              */
/*    e-mail: nomad@gerad.ca                                                       */
/*    phone : 1-514-340-6053 #6928                                                 */
/*    fax   : 1-514-340-5665                                                       */
/*                                                                                 */
/*  This program is free software: you can redistribute it and/or modify it        */
/*  under the terms of the GNU Lesser General Public License as published by       */
/*  the Free Software Foundation, either version 3 of the License, or (at your     */
/*  option) any later version.                                                     */
/*                                                                                 */
/*  This program is distributed in the hope that it will be useful, but WITHOUT    */
/*  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or          */
/*  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License    */
/*  for more details.                                                              */
/*                                                                                 */
/*  You should have received a copy of the GNU Lesser General Public License       */
/*  along with this program. If not, see <http://www.gnu.org/licenses/>.           */
/*                                                                                 */
/*  You can find information on the NOMAD software at www.gerad.ca/nomad           */
/*---------------------------------------------------------------------------------*/
#ifndef __NOMAD400_NMINITIALIZATION__
#define __NOMAD400_NMINITIALIZATION__

#include "../../Algos/Initialization.hpp"

#include "../../Algos/NelderMead/NMIterationUtils.hpp"

#include "../../nomad_nsbegin.hpp"

/// Class for Nelder Mead initilization
/**
 * For Step 0 of NM algorithm: Create and evaluate (if needed) trial points that will be used to form simplex. The points are put in cache.
 */
class NMInitialization: public Initialization, public NMIterationUtils
{
private:
    
    std::shared_ptr<AlgoStopReasons<NMStopType>> _nmStopReason;
    
public:
    /// Constructor
    /*
     \param parentStep      The parent of this step -- \b IN.
     */
    explicit NMInitialization(const Step* parentStep)
      : Initialization(parentStep),
        NMIterationUtils(parentStep)
    {
        init();
    }
    
    /// Destructor
    virtual ~NMInitialization() {}


private:
    /// Helper for constructor
    void init();
    
    /// Implementation of start task
    /**
     If needed, generate trial points and put them in cache to form simplex.
     For a standalone optimization (NM_OPTIMIZATION true), initial trial points must be generated to form a valid simplex around x0. Otherwise, the cache will be used to construct the simplex.
     */
    virtual void startImp() override ;
    
    /// Implementation of run task
    /**
     For a standalone NM, evaluate the trial points generated during start (simplex is created later)
     Otherwise, there are no trial points available and a failed stop reason is set.
     */
    virtual bool runImp() override ;
    

    /// Generate new points to form simplex
    void generateTrialPoints() override;
    
    /// Helper for start
    bool checkCacheCanFormSimplex ( void );

};

#include "../../nomad_nsend.hpp"

#endif // __NOMAD400_NMINITIALIZATION__
